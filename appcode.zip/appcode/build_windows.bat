@echo off
REM build_windows.bat
REM =================
REM Builds both Windows components: win_bridge_server and rtos_receiver
REM Run this on the Windows machine with MinGW (gcc) or MSVC in PATH.

setlocal

echo ============================
echo  Building Windows Bridge Server
echo ============================
gcc -Wall -o win_bridge\win_bridge_server.exe win_bridge\win_bridge_server.c -lws2_32
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] win_bridge_server build failed.
    exit /b 1
)
echo [OK] win_bridge\win_bridge_server.exe

echo.
echo ============================
echo  Building RTOS Receiver
echo ============================
gcc -Wall -o rtos_app\rtos_receiver.exe rtos_app\rtos_receiver.c -lws2_32
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] rtos_receiver build failed.
    exit /b 1
)
echo [OK] rtos_app\rtos_receiver.exe

echo.
echo ============================
echo  All Windows builds succeeded.
echo ============================
echo.
echo Usage:
echo   1. Start RTOS Receiver first:
echo      rtos_app\rtos_receiver.exe [C:\your\save\folder]
echo.
echo   2. Then start the Bridge Server:
echo      win_bridge\win_bridge_server.exe [rtos_ip]
echo      (rtos_ip defaults to 127.0.0.1 if RTOS runs on same machine)
endlocal
